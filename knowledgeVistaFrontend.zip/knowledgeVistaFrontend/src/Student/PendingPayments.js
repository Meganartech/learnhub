import React from 'react'

const PendingPayments = () => {
  return (
    <div>
      
    </div>
  )
}

export default PendingPayments
